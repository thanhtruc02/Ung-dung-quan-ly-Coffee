﻿using QLQCP.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQCP
{
    public partial class fAdmin : Form
    {
        public fAdmin()
        {
            InitializeComponent();

            LoadTaiKhoanList();
        }

        void LoadFoodList()
        {
            string query = "SELECT * FROM THUCAN";

            dtgvMonan.DataSource = DataProvider.Instance.ExecuteQuery(query);
        }
        void LoadTaiKhoanList()
        {
            string query = "EXEC dbo.TAIKHOAN_TenUser @ten";

            dtgvTaikhoan.DataSource = DataProvider.Instance.ExecuteQuery(query, new object[] { "chuppa" });
        }
    }
}
