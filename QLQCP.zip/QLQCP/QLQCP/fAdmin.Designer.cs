﻿namespace QLQCP
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tcAdmin = new System.Windows.Forms.TabControl();
            this.tcDoanhthu = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnXemthongke = new System.Windows.Forms.Button();
            this.dtDenngay = new System.Windows.Forms.DateTimePicker();
            this.dtTungay = new System.Windows.Forms.DateTimePicker();
            this.panel12 = new System.Windows.Forms.Panel();
            this.dtgvDoanhthu = new System.Windows.Forms.DataGridView();
            this.tpMonan = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.nmGiamon = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.cbDanhmucMonan = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtTenmon = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtMaMonan = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtTimtenmon = new System.Windows.Forms.TextBox();
            this.btnTimmon = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnXemmon = new System.Windows.Forms.Button();
            this.btnSuamon = new System.Windows.Forms.Button();
            this.btnXoamon = new System.Windows.Forms.Button();
            this.btnThemmon = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtgvMonan = new System.Windows.Forms.DataGridView();
            this.tpPhanLoai = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txtMaLoai = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btnXemloai = new System.Windows.Forms.Button();
            this.btnSualoai = new System.Windows.Forms.Button();
            this.btnXoaloai = new System.Windows.Forms.Button();
            this.btnThemLoai = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.dtgvPhanLoai = new System.Windows.Forms.DataGridView();
            this.tpBan = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnXemban = new System.Windows.Forms.Button();
            this.btnSuaban = new System.Windows.Forms.Button();
            this.btnXoaban = new System.Windows.Forms.Button();
            this.btnThemban = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.dtgvBan = new System.Windows.Forms.DataGridView();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.cbTinhtrangBan = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txtTenban = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tpTaikhoan = new System.Windows.Forms.TabPage();
            this.panel22 = new System.Windows.Forms.Panel();
            this.btnDatlaiMK = new System.Windows.Forms.Button();
            this.panel24 = new System.Windows.Forms.Panel();
            this.cbLoaitaikhoan = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txtTenhienthi = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.txtTentaikhoan = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.btnXemtaikhoan = new System.Windows.Forms.Button();
            this.btnSuataikhoan = new System.Windows.Forms.Button();
            this.btnXoataikhoan = new System.Windows.Forms.Button();
            this.btnThemtaikhoan = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.dtgvTaikhoan = new System.Windows.Forms.DataGridView();
            this.tcAdmin.SuspendLayout();
            this.tcDoanhthu.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDoanhthu)).BeginInit();
            this.tpMonan.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGiamon)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvMonan)).BeginInit();
            this.tpPhanLoai.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPhanLoai)).BeginInit();
            this.tpBan.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBan)).BeginInit();
            this.panel16.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.tpTaikhoan.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaikhoan)).BeginInit();
            this.SuspendLayout();
            // 
            // tcAdmin
            // 
            this.tcAdmin.Controls.Add(this.tcDoanhthu);
            this.tcAdmin.Controls.Add(this.tpMonan);
            this.tcAdmin.Controls.Add(this.tpPhanLoai);
            this.tcAdmin.Controls.Add(this.tpBan);
            this.tcAdmin.Controls.Add(this.tpTaikhoan);
            this.tcAdmin.Location = new System.Drawing.Point(4, 8);
            this.tcAdmin.Name = "tcAdmin";
            this.tcAdmin.SelectedIndex = 0;
            this.tcAdmin.Size = new System.Drawing.Size(793, 434);
            this.tcAdmin.TabIndex = 1;
            // 
            // tcDoanhthu
            // 
            this.tcDoanhthu.Controls.Add(this.panel11);
            this.tcDoanhthu.Controls.Add(this.panel12);
            this.tcDoanhthu.Location = new System.Drawing.Point(4, 22);
            this.tcDoanhthu.Name = "tcDoanhthu";
            this.tcDoanhthu.Padding = new System.Windows.Forms.Padding(3);
            this.tcDoanhthu.Size = new System.Drawing.Size(785, 408);
            this.tcDoanhthu.TabIndex = 0;
            this.tcDoanhthu.Text = "Doanh thu";
            this.tcDoanhthu.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.btnXemthongke);
            this.panel11.Controls.Add(this.dtDenngay);
            this.panel11.Controls.Add(this.dtTungay);
            this.panel11.Location = new System.Drawing.Point(4, 7);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(776, 42);
            this.panel11.TabIndex = 3;
            // 
            // btnXemthongke
            // 
            this.btnXemthongke.Location = new System.Drawing.Point(454, 6);
            this.btnXemthongke.Name = "btnXemthongke";
            this.btnXemthongke.Size = new System.Drawing.Size(67, 30);
            this.btnXemthongke.TabIndex = 2;
            this.btnXemthongke.Text = "Xem";
            this.btnXemthongke.UseVisualStyleBackColor = true;
            // 
            // dtDenngay
            // 
            this.dtDenngay.Location = new System.Drawing.Point(228, 12);
            this.dtDenngay.Name = "dtDenngay";
            this.dtDenngay.Size = new System.Drawing.Size(200, 20);
            this.dtDenngay.TabIndex = 1;
            // 
            // dtTungay
            // 
            this.dtTungay.Location = new System.Drawing.Point(4, 12);
            this.dtTungay.Name = "dtTungay";
            this.dtTungay.Size = new System.Drawing.Size(200, 20);
            this.dtTungay.TabIndex = 0;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.dtgvDoanhthu);
            this.panel12.Location = new System.Drawing.Point(4, 55);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(776, 347);
            this.panel12.TabIndex = 2;
            // 
            // dtgvDoanhthu
            // 
            this.dtgvDoanhthu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDoanhthu.Location = new System.Drawing.Point(3, 3);
            this.dtgvDoanhthu.Name = "dtgvDoanhthu";
            this.dtgvDoanhthu.Size = new System.Drawing.Size(770, 341);
            this.dtgvDoanhthu.TabIndex = 0;
            // 
            // tpMonan
            // 
            this.tpMonan.Controls.Add(this.panel6);
            this.tpMonan.Controls.Add(this.panel5);
            this.tpMonan.Controls.Add(this.panel4);
            this.tpMonan.Controls.Add(this.panel3);
            this.tpMonan.Location = new System.Drawing.Point(4, 22);
            this.tpMonan.Name = "tpMonan";
            this.tpMonan.Padding = new System.Windows.Forms.Padding(3);
            this.tpMonan.Size = new System.Drawing.Size(785, 408);
            this.tpMonan.TabIndex = 1;
            this.tpMonan.Text = "Món ăn";
            this.tpMonan.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(407, 93);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(372, 309);
            this.panel6.TabIndex = 3;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.nmGiamon);
            this.panel10.Controls.Add(this.label4);
            this.panel10.Location = new System.Drawing.Point(3, 201);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(366, 60);
            this.panel10.TabIndex = 4;
            // 
            // nmGiamon
            // 
            this.nmGiamon.Location = new System.Drawing.Point(98, 18);
            this.nmGiamon.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.nmGiamon.Name = "nmGiamon";
            this.nmGiamon.Size = new System.Drawing.Size(254, 20);
            this.nmGiamon.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Giá:";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.cbDanhmucMonan);
            this.panel9.Controls.Add(this.label3);
            this.panel9.Location = new System.Drawing.Point(3, 135);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(366, 60);
            this.panel9.TabIndex = 3;
            // 
            // cbDanhmucMonan
            // 
            this.cbDanhmucMonan.FormattingEnabled = true;
            this.cbDanhmucMonan.Location = new System.Drawing.Point(98, 20);
            this.cbDanhmucMonan.Name = "cbDanhmucMonan";
            this.cbDanhmucMonan.Size = new System.Drawing.Size(254, 21);
            this.cbDanhmucMonan.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Danh mục:";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtTenmon);
            this.panel8.Controls.Add(this.label2);
            this.panel8.Location = new System.Drawing.Point(3, 69);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(366, 60);
            this.panel8.TabIndex = 2;
            // 
            // txtTenmon
            // 
            this.txtTenmon.Location = new System.Drawing.Point(98, 19);
            this.txtTenmon.Name = "txtTenmon";
            this.txtTenmon.ReadOnly = true;
            this.txtTenmon.Size = new System.Drawing.Size(254, 20);
            this.txtTenmon.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên món:";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txtMaMonan);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(366, 60);
            this.panel7.TabIndex = 1;
            // 
            // txtMaMonan
            // 
            this.txtMaMonan.Location = new System.Drawing.Point(98, 19);
            this.txtMaMonan.Name = "txtMaMonan";
            this.txtMaMonan.ReadOnly = true;
            this.txtMaMonan.Size = new System.Drawing.Size(254, 20);
            this.txtMaMonan.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtTimtenmon);
            this.panel5.Controls.Add(this.btnTimmon);
            this.panel5.Location = new System.Drawing.Point(407, 7);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(372, 79);
            this.panel5.TabIndex = 2;
            // 
            // txtTimtenmon
            // 
            this.txtTimtenmon.Location = new System.Drawing.Point(14, 30);
            this.txtTimtenmon.Name = "txtTimtenmon";
            this.txtTimtenmon.Size = new System.Drawing.Size(274, 20);
            this.txtTimtenmon.TabIndex = 5;
            // 
            // btnTimmon
            // 
            this.btnTimmon.Location = new System.Drawing.Point(294, 3);
            this.btnTimmon.Name = "btnTimmon";
            this.btnTimmon.Size = new System.Drawing.Size(75, 74);
            this.btnTimmon.TabIndex = 4;
            this.btnTimmon.Text = "Tìm món";
            this.btnTimmon.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnXemmon);
            this.panel4.Controls.Add(this.btnSuamon);
            this.panel4.Controls.Add(this.btnXoamon);
            this.panel4.Controls.Add(this.btnThemmon);
            this.panel4.Location = new System.Drawing.Point(6, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(395, 80);
            this.panel4.TabIndex = 1;
            // 
            // btnXemmon
            // 
            this.btnXemmon.Location = new System.Drawing.Point(248, 3);
            this.btnXemmon.Name = "btnXemmon";
            this.btnXemmon.Size = new System.Drawing.Size(75, 74);
            this.btnXemmon.TabIndex = 3;
            this.btnXemmon.Text = "Xem món";
            this.btnXemmon.UseVisualStyleBackColor = true;
            // 
            // btnSuamon
            // 
            this.btnSuamon.Location = new System.Drawing.Point(167, 3);
            this.btnSuamon.Name = "btnSuamon";
            this.btnSuamon.Size = new System.Drawing.Size(75, 74);
            this.btnSuamon.TabIndex = 2;
            this.btnSuamon.Text = "Sửa món";
            this.btnSuamon.UseVisualStyleBackColor = true;
            // 
            // btnXoamon
            // 
            this.btnXoamon.Location = new System.Drawing.Point(86, 3);
            this.btnXoamon.Name = "btnXoamon";
            this.btnXoamon.Size = new System.Drawing.Size(75, 74);
            this.btnXoamon.TabIndex = 1;
            this.btnXoamon.Text = "Xóa món";
            this.btnXoamon.UseVisualStyleBackColor = true;
            // 
            // btnThemmon
            // 
            this.btnThemmon.Location = new System.Drawing.Point(5, 3);
            this.btnThemmon.Name = "btnThemmon";
            this.btnThemmon.Size = new System.Drawing.Size(75, 74);
            this.btnThemmon.TabIndex = 0;
            this.btnThemmon.Text = "Thêm món";
            this.btnThemmon.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dtgvMonan);
            this.panel3.Location = new System.Drawing.Point(7, 92);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(394, 310);
            this.panel3.TabIndex = 0;
            // 
            // dtgvMonan
            // 
            this.dtgvMonan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvMonan.Location = new System.Drawing.Point(4, 4);
            this.dtgvMonan.Name = "dtgvMonan";
            this.dtgvMonan.Size = new System.Drawing.Size(387, 303);
            this.dtgvMonan.TabIndex = 0;
            // 
            // tpPhanLoai
            // 
            this.tpPhanLoai.Controls.Add(this.panel1);
            this.tpPhanLoai.Controls.Add(this.panel17);
            this.tpPhanLoai.Controls.Add(this.panel18);
            this.tpPhanLoai.Location = new System.Drawing.Point(4, 22);
            this.tpPhanLoai.Name = "tpPhanLoai";
            this.tpPhanLoai.Padding = new System.Windows.Forms.Padding(3);
            this.tpPhanLoai.Size = new System.Drawing.Size(785, 408);
            this.tpPhanLoai.TabIndex = 2;
            this.tpPhanLoai.Text = "Danh mục";
            this.tpPhanLoai.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Location = new System.Drawing.Point(407, 93);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(372, 309);
            this.panel1.TabIndex = 7;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.textBox1);
            this.panel14.Controls.Add(this.label7);
            this.panel14.Location = new System.Drawing.Point(3, 69);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(366, 60);
            this.panel14.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(133, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(219, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tên danh mục:";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.txtMaLoai);
            this.panel15.Controls.Add(this.label8);
            this.panel15.Location = new System.Drawing.Point(3, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(366, 60);
            this.panel15.TabIndex = 1;
            // 
            // txtMaLoai
            // 
            this.txtMaLoai.Location = new System.Drawing.Point(133, 19);
            this.txtMaLoai.Name = "txtMaLoai";
            this.txtMaLoai.ReadOnly = true;
            this.txtMaLoai.Size = new System.Drawing.Size(219, 20);
            this.txtMaLoai.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "ID:";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.btnXemloai);
            this.panel17.Controls.Add(this.btnSualoai);
            this.panel17.Controls.Add(this.btnXoaloai);
            this.panel17.Controls.Add(this.btnThemLoai);
            this.panel17.Location = new System.Drawing.Point(6, 6);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(395, 80);
            this.panel17.TabIndex = 5;
            // 
            // btnXemloai
            // 
            this.btnXemloai.Location = new System.Drawing.Point(248, 3);
            this.btnXemloai.Name = "btnXemloai";
            this.btnXemloai.Size = new System.Drawing.Size(75, 74);
            this.btnXemloai.TabIndex = 3;
            this.btnXemloai.Text = "Xem";
            this.btnXemloai.UseVisualStyleBackColor = true;
            // 
            // btnSualoai
            // 
            this.btnSualoai.Location = new System.Drawing.Point(167, 3);
            this.btnSualoai.Name = "btnSualoai";
            this.btnSualoai.Size = new System.Drawing.Size(75, 74);
            this.btnSualoai.TabIndex = 2;
            this.btnSualoai.Text = "Sửa";
            this.btnSualoai.UseVisualStyleBackColor = true;
            // 
            // btnXoaloai
            // 
            this.btnXoaloai.Location = new System.Drawing.Point(86, 3);
            this.btnXoaloai.Name = "btnXoaloai";
            this.btnXoaloai.Size = new System.Drawing.Size(75, 74);
            this.btnXoaloai.TabIndex = 1;
            this.btnXoaloai.Text = "Xóa";
            this.btnXoaloai.UseVisualStyleBackColor = true;
            // 
            // btnThemLoai
            // 
            this.btnThemLoai.Location = new System.Drawing.Point(5, 3);
            this.btnThemLoai.Name = "btnThemLoai";
            this.btnThemLoai.Size = new System.Drawing.Size(75, 74);
            this.btnThemLoai.TabIndex = 0;
            this.btnThemLoai.Text = "Thêm";
            this.btnThemLoai.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.dtgvPhanLoai);
            this.panel18.Location = new System.Drawing.Point(7, 92);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(394, 310);
            this.panel18.TabIndex = 4;
            // 
            // dtgvPhanLoai
            // 
            this.dtgvPhanLoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvPhanLoai.Location = new System.Drawing.Point(4, 4);
            this.dtgvPhanLoai.Name = "dtgvPhanLoai";
            this.dtgvPhanLoai.Size = new System.Drawing.Size(387, 303);
            this.dtgvPhanLoai.TabIndex = 0;
            // 
            // tpBan
            // 
            this.tpBan.Controls.Add(this.panel2);
            this.tpBan.Controls.Add(this.panel13);
            this.tpBan.Controls.Add(this.panel16);
            this.tpBan.Location = new System.Drawing.Point(4, 22);
            this.tpBan.Name = "tpBan";
            this.tpBan.Padding = new System.Windows.Forms.Padding(3);
            this.tpBan.Size = new System.Drawing.Size(785, 408);
            this.tpBan.TabIndex = 3;
            this.tpBan.Text = "Bàn ăn";
            this.tpBan.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnXemban);
            this.panel2.Controls.Add(this.btnSuaban);
            this.panel2.Controls.Add(this.btnXoaban);
            this.panel2.Controls.Add(this.btnThemban);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(395, 80);
            this.panel2.TabIndex = 9;
            // 
            // btnXemban
            // 
            this.btnXemban.Location = new System.Drawing.Point(248, 3);
            this.btnXemban.Name = "btnXemban";
            this.btnXemban.Size = new System.Drawing.Size(75, 74);
            this.btnXemban.TabIndex = 3;
            this.btnXemban.Text = "Xem ";
            this.btnXemban.UseVisualStyleBackColor = true;
            // 
            // btnSuaban
            // 
            this.btnSuaban.Location = new System.Drawing.Point(167, 3);
            this.btnSuaban.Name = "btnSuaban";
            this.btnSuaban.Size = new System.Drawing.Size(75, 74);
            this.btnSuaban.TabIndex = 2;
            this.btnSuaban.Text = "Sửa ";
            this.btnSuaban.UseVisualStyleBackColor = true;
            // 
            // btnXoaban
            // 
            this.btnXoaban.Location = new System.Drawing.Point(86, 3);
            this.btnXoaban.Name = "btnXoaban";
            this.btnXoaban.Size = new System.Drawing.Size(75, 74);
            this.btnXoaban.TabIndex = 1;
            this.btnXoaban.Text = "Xóa";
            this.btnXoaban.UseVisualStyleBackColor = true;
            // 
            // btnThemban
            // 
            this.btnThemban.Location = new System.Drawing.Point(5, 3);
            this.btnThemban.Name = "btnThemban";
            this.btnThemban.Size = new System.Drawing.Size(75, 74);
            this.btnThemban.TabIndex = 0;
            this.btnThemban.Text = "Thêm";
            this.btnThemban.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.dtgvBan);
            this.panel13.Location = new System.Drawing.Point(7, 92);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(394, 310);
            this.panel13.TabIndex = 8;
            // 
            // dtgvBan
            // 
            this.dtgvBan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvBan.Location = new System.Drawing.Point(4, 4);
            this.dtgvBan.Name = "dtgvBan";
            this.dtgvBan.Size = new System.Drawing.Size(387, 303);
            this.dtgvBan.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.panel21);
            this.panel16.Controls.Add(this.panel19);
            this.panel16.Controls.Add(this.panel20);
            this.panel16.Location = new System.Drawing.Point(407, 93);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(372, 309);
            this.panel16.TabIndex = 10;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.cbTinhtrangBan);
            this.panel21.Controls.Add(this.label9);
            this.panel21.Location = new System.Drawing.Point(3, 135);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(366, 60);
            this.panel21.TabIndex = 3;
            // 
            // cbTinhtrangBan
            // 
            this.cbTinhtrangBan.FormattingEnabled = true;
            this.cbTinhtrangBan.Location = new System.Drawing.Point(133, 20);
            this.cbTinhtrangBan.Name = "cbTinhtrangBan";
            this.cbTinhtrangBan.Size = new System.Drawing.Size(219, 21);
            this.cbTinhtrangBan.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 19);
            this.label9.TabIndex = 0;
            this.label9.Text = "Trạng thái:";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.txtTenban);
            this.panel19.Controls.Add(this.label5);
            this.panel19.Location = new System.Drawing.Point(3, 69);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(366, 60);
            this.panel19.TabIndex = 2;
            // 
            // txtTenban
            // 
            this.txtTenban.Location = new System.Drawing.Point(133, 19);
            this.txtTenban.Name = "txtTenban";
            this.txtTenban.ReadOnly = true;
            this.txtTenban.Size = new System.Drawing.Size(219, 20);
            this.txtTenban.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tên bàn:";
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.textBox3);
            this.panel20.Controls.Add(this.label6);
            this.panel20.Location = new System.Drawing.Point(3, 3);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(366, 60);
            this.panel20.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(133, 19);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(219, 20);
            this.textBox3.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "ID:";
            // 
            // tpTaikhoan
            // 
            this.tpTaikhoan.Controls.Add(this.panel22);
            this.tpTaikhoan.Controls.Add(this.panel28);
            this.tpTaikhoan.Controls.Add(this.panel29);
            this.tpTaikhoan.Location = new System.Drawing.Point(4, 22);
            this.tpTaikhoan.Name = "tpTaikhoan";
            this.tpTaikhoan.Padding = new System.Windows.Forms.Padding(3);
            this.tpTaikhoan.Size = new System.Drawing.Size(785, 408);
            this.tpTaikhoan.TabIndex = 4;
            this.tpTaikhoan.Text = "Tài khoản";
            this.tpTaikhoan.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.btnDatlaiMK);
            this.panel22.Controls.Add(this.panel24);
            this.panel22.Controls.Add(this.panel25);
            this.panel22.Controls.Add(this.panel26);
            this.panel22.Location = new System.Drawing.Point(407, 93);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(372, 309);
            this.panel22.TabIndex = 7;
            // 
            // btnDatlaiMK
            // 
            this.btnDatlaiMK.Location = new System.Drawing.Point(270, 201);
            this.btnDatlaiMK.Name = "btnDatlaiMK";
            this.btnDatlaiMK.Size = new System.Drawing.Size(99, 74);
            this.btnDatlaiMK.TabIndex = 4;
            this.btnDatlaiMK.Text = "Đặt lại mật khẩu";
            this.btnDatlaiMK.UseVisualStyleBackColor = true;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.cbLoaitaikhoan);
            this.panel24.Controls.Add(this.label11);
            this.panel24.Location = new System.Drawing.Point(3, 135);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(366, 60);
            this.panel24.TabIndex = 3;
            // 
            // cbLoaitaikhoan
            // 
            this.cbLoaitaikhoan.FormattingEnabled = true;
            this.cbLoaitaikhoan.Location = new System.Drawing.Point(127, 20);
            this.cbLoaitaikhoan.Name = "cbLoaitaikhoan";
            this.cbLoaitaikhoan.Size = new System.Drawing.Size(225, 21);
            this.cbLoaitaikhoan.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 19);
            this.label11.TabIndex = 0;
            this.label11.Text = "Loại tài khoản:";
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.txtTenhienthi);
            this.panel25.Controls.Add(this.label12);
            this.panel25.Location = new System.Drawing.Point(3, 69);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(366, 60);
            this.panel25.TabIndex = 2;
            // 
            // txtTenhienthi
            // 
            this.txtTenhienthi.Location = new System.Drawing.Point(127, 19);
            this.txtTenhienthi.Name = "txtTenhienthi";
            this.txtTenhienthi.ReadOnly = true;
            this.txtTenhienthi.Size = new System.Drawing.Size(225, 20);
            this.txtTenhienthi.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 19);
            this.label12.TabIndex = 0;
            this.label12.Text = "Tên hiển thị:";
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.txtTentaikhoan);
            this.panel26.Controls.Add(this.label13);
            this.panel26.Location = new System.Drawing.Point(3, 3);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(366, 60);
            this.panel26.TabIndex = 1;
            // 
            // txtTentaikhoan
            // 
            this.txtTentaikhoan.Location = new System.Drawing.Point(127, 19);
            this.txtTentaikhoan.Name = "txtTentaikhoan";
            this.txtTentaikhoan.ReadOnly = true;
            this.txtTentaikhoan.Size = new System.Drawing.Size(225, 20);
            this.txtTentaikhoan.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 19);
            this.label13.TabIndex = 0;
            this.label13.Text = "Tên tài khoản:";
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.btnXemtaikhoan);
            this.panel28.Controls.Add(this.btnSuataikhoan);
            this.panel28.Controls.Add(this.btnXoataikhoan);
            this.panel28.Controls.Add(this.btnThemtaikhoan);
            this.panel28.Location = new System.Drawing.Point(6, 6);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(395, 80);
            this.panel28.TabIndex = 5;
            // 
            // btnXemtaikhoan
            // 
            this.btnXemtaikhoan.Location = new System.Drawing.Point(248, 3);
            this.btnXemtaikhoan.Name = "btnXemtaikhoan";
            this.btnXemtaikhoan.Size = new System.Drawing.Size(75, 74);
            this.btnXemtaikhoan.TabIndex = 3;
            this.btnXemtaikhoan.Text = "Xem";
            this.btnXemtaikhoan.UseVisualStyleBackColor = true;
            // 
            // btnSuataikhoan
            // 
            this.btnSuataikhoan.Location = new System.Drawing.Point(167, 3);
            this.btnSuataikhoan.Name = "btnSuataikhoan";
            this.btnSuataikhoan.Size = new System.Drawing.Size(75, 74);
            this.btnSuataikhoan.TabIndex = 2;
            this.btnSuataikhoan.Text = "Sửa";
            this.btnSuataikhoan.UseVisualStyleBackColor = true;
            // 
            // btnXoataikhoan
            // 
            this.btnXoataikhoan.Location = new System.Drawing.Point(86, 3);
            this.btnXoataikhoan.Name = "btnXoataikhoan";
            this.btnXoataikhoan.Size = new System.Drawing.Size(75, 74);
            this.btnXoataikhoan.TabIndex = 1;
            this.btnXoataikhoan.Text = "Xóa";
            this.btnXoataikhoan.UseVisualStyleBackColor = true;
            // 
            // btnThemtaikhoan
            // 
            this.btnThemtaikhoan.Location = new System.Drawing.Point(5, 3);
            this.btnThemtaikhoan.Name = "btnThemtaikhoan";
            this.btnThemtaikhoan.Size = new System.Drawing.Size(75, 74);
            this.btnThemtaikhoan.TabIndex = 0;
            this.btnThemtaikhoan.Text = "Thêm";
            this.btnThemtaikhoan.UseVisualStyleBackColor = true;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.dtgvTaikhoan);
            this.panel29.Location = new System.Drawing.Point(7, 92);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(394, 310);
            this.panel29.TabIndex = 4;
            // 
            // dtgvTaikhoan
            // 
            this.dtgvTaikhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvTaikhoan.Location = new System.Drawing.Point(4, 4);
            this.dtgvTaikhoan.Name = "dtgvTaikhoan";
            this.dtgvTaikhoan.Size = new System.Drawing.Size(387, 303);
            this.dtgvTaikhoan.TabIndex = 0;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tcAdmin);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.tcAdmin.ResumeLayout(false);
            this.tcDoanhthu.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDoanhthu)).EndInit();
            this.tpMonan.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGiamon)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvMonan)).EndInit();
            this.tpPhanLoai.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPhanLoai)).EndInit();
            this.tpBan.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBan)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.tpTaikhoan.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaikhoan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcAdmin;
        private System.Windows.Forms.TabPage tcDoanhthu;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btnXemthongke;
        private System.Windows.Forms.DateTimePicker dtDenngay;
        private System.Windows.Forms.DateTimePicker dtTungay;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.DataGridView dtgvDoanhthu;
        private System.Windows.Forms.TabPage tpMonan;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.NumericUpDown nmGiamon;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox cbDanhmucMonan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtTenmon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtMaMonan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtTimtenmon;
        private System.Windows.Forms.Button btnTimmon;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnXemmon;
        private System.Windows.Forms.Button btnSuamon;
        private System.Windows.Forms.Button btnXoamon;
        private System.Windows.Forms.Button btnThemmon;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dtgvMonan;
        private System.Windows.Forms.TabPage tpPhanLoai;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txtMaLoai;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button btnXemloai;
        private System.Windows.Forms.Button btnSualoai;
        private System.Windows.Forms.Button btnXoaloai;
        private System.Windows.Forms.Button btnThemLoai;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.DataGridView dtgvPhanLoai;
        private System.Windows.Forms.TabPage tpBan;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnXemban;
        private System.Windows.Forms.Button btnSuaban;
        private System.Windows.Forms.Button btnXoaban;
        private System.Windows.Forms.Button btnThemban;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.DataGridView dtgvBan;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.ComboBox cbTinhtrangBan;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txtTenban;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tpTaikhoan;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button btnDatlaiMK;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.ComboBox cbLoaitaikhoan;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txtTenhienthi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox txtTentaikhoan;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button btnXemtaikhoan;
        private System.Windows.Forms.Button btnSuataikhoan;
        private System.Windows.Forms.Button btnXoataikhoan;
        private System.Windows.Forms.Button btnThemtaikhoan;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.DataGridView dtgvTaikhoan;
    }
}