﻿using QLQCP.DAO;
using QLQCP.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms;

namespace QLQCP
{
    public partial class fQLBan : Form
    {
        public fQLBan()
        {
            InitializeComponent();
            LoadBan();
            LoadPhanLloai();
        }
      
        #region Method

        void LoadPhanLloai()
        {
            List<DTO_PHANLOAI> dsPhanLoai = DAO_PHANLOAI.Instance.DANHSACHPHANLOAI();
            cbPhanLoai.DataSource = dsPhanLoai;
            cbPhanLoai.DisplayMember = "Ten";
        }

        void LoadDSMon_MaLoaiTU(int id)
        {
            List<DTO_THUCUONG> dsMon = DAO_THUCUONG.Instance.DSTHUCUONG_MALOAITU(id);
            cbMon.DataSource = dsMon;
            cbMon.DisplayMember = "Ten";
        }
        void LoadBan()
        {
            flpBan.Controls.Clear();
            List<DTO_BAN> banList = DAO_BAN.Instance.LoadBanList();

            foreach (DTO_BAN item in banList)
            {
                Button btn = new Button()
                {
                    Width = DAO_BAN.WidthBan,
                    Height = DAO_BAN.HeightBan
                };
                btn.Text = item.TenB + Environment.NewLine + item.Trangthai;
                btn.Click += btn_Click;
                btn.Tag = item;

                switch (item.Trangthai)
                {
                    case "Trong":
                        btn.BackColor = Color.Aqua;
                        break;
                    default:
                        btn.BackColor = Color.RosyBrown;
                        break;
                }
                flpBan.Controls.Add(btn);
            }
        }

        void HienthiHoaDon(int Ma)
        {
            lsvHoaDon.Items.Clear();
            List<ThucDon> dsCTHD = DAO_THUCDON.Instance.DANHSACHTHUCDON_MAB(Ma);
            float ThanhTien = 0;

            foreach (ThucDon item in  dsCTHD)
            {
                ListViewItem lsvItem = new ListViewItem(item.TenTU.ToString());
                lsvItem.SubItems.Add(item.Count.ToString());
                lsvItem.SubItems.Add(item.Gia.ToString());
                lsvItem.SubItems.Add(item.ThanhTien.ToString());
                ThanhTien+= item.ThanhTien;

                lsvHoaDon.Items.Add(lsvItem);
            }
            CultureInfo culture = new CultureInfo("vi-VN");
            txtTongtien.Text = ThanhTien.ToString("c",culture);

        }
        #endregion

        #region Events

        void btn_Click (object sender, EventArgs e)
        {
            int maB = ((sender as Button).Tag as DTO_BAN).MaB;
            lsvHoaDon.Tag = (sender as Button).Tag;
            HienthiHoaDon(maB);
        }
        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fThongtinTK f = new fThongtinTK();
            f.ShowDialog();
        }
        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAdmin f = new fAdmin();
            f.ShowDialog();
        }

        private void cbPhanLoai_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = 0;

            ComboBox cb = sender as ComboBox;

            if (cb.SelectedItem == null)
                return;
            DTO_PHANLOAI selected = cb.SelectedItem as DTO_PHANLOAI;
            id = selected.MA;
            LoadDSMon_MaLoaiTU(id);
        }

        private void btThemMon_Click(object sender, EventArgs e)
        {
            DTO_BAN table = lsvHoaDon.Tag as DTO_BAN;

            int idHD = DAO_HOADON.Instance.DSHOADON_MABAN(table.MaB);
            int idTU = (cbMon.SelectedItem as DTO_THUCUONG).MA;
            int soluong = (int)nmSLMon.Value;

            if (idHD == -1)
            {
                DAO_HOADON.Instance.ThemHoaDon(table.MaB);
                DAO_CTHD.Instance.ThemCTHD(DAO_HOADON.Instance.GetMaxIDBill(), idTU, soluong) ;
            }
            else
            {
                DAO_CTHD.Instance.ThemCTHD(idHD, idTU, soluong);

            }

            HienthiHoaDon(table.MaB);
            LoadBan();

        }
        private void btnThanhtoan_Click(object sender, EventArgs e)
        {
            DTO_BAN table = lsvHoaDon.Tag as DTO_BAN;

            int idHD = DAO_HOADON.Instance.DSHOADON_MABAN(table.MaB);

            if(idHD != -1)
            {
                if (MessageBox.Show("Ban co chac thanh toan hoa don cho " + table.TenB, "Thong bao", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK) ;
                {
                    DAO_HOADON.Instance.CheckOut(idHD);
                    HienthiHoaDon(table.MaB);
                    LoadBan();

                }
            }
        }

        #endregion
        private void fQLBan_Load(object sender, EventArgs e)
        {

        }

        
    }
    
}
