﻿using QLQCP.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQCP.DAO
{
    public class DAO_THUCUONG
    {
        private static DAO_THUCUONG instance;

        public static DAO_THUCUONG Instance
        {
            get { if (instance == null) instance = new DAO_THUCUONG(); return DAO_THUCUONG.instance; }
            private set { DAO_THUCUONG.instance = value; }
        }

        private DAO_THUCUONG() { }

        public List<DTO_THUCUONG> DSTHUCUONG_MALOAITU(int id)
        {
            List<DTO_THUCUONG> ds = new List<DTO_THUCUONG>();

            string query = "SELECT * FROM THUCUONG WHERE MaLoaiTU = " + id;

            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows) 
            {
                DTO_THUCUONG thucuong = new DTO_THUCUONG(item);
                ds.Add(thucuong);
            }

            return ds;
        }
    }
}
