﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQCP.DAO
{
    public class DAO_TAIKHOAN
    {
        private static DAO_TAIKHOAN instance;

        public static DAO_TAIKHOAN Instance
        {
            get { if (instance == null) instance = new DAO_TAIKHOAN(); return instance; }
            private set { instance = value; }
        }

        private DAO_TAIKHOAN() { }

        public bool Login(string tenUser, string matkhau)
        {
            string query = "DANGNHAP @ten , @mk";
            DataTable ketqua = DataProvider.Instance.ExecuteQuery(query, new object[] { tenUser, matkhau });
            return ketqua.Rows.Count > 0;
        }

    }
}
