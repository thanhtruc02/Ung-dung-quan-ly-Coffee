﻿using QLQCP.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQCP.DAO
{
    public class DAO_PHANLOAI
    {
        private static DAO_PHANLOAI instance;

        public static DAO_PHANLOAI Instance
        {
            get { if(instance == null)instance = new DAO_PHANLOAI();return DAO_PHANLOAI.instance; }
            private set { DAO_PHANLOAI.instance = value; }
        }

        private DAO_PHANLOAI() { }

        public List<DTO_PHANLOAI> DANHSACHPHANLOAI()
        {
            List<DTO_PHANLOAI> ds = new List<DTO_PHANLOAI> ();

            string query = "SELECT * FROM LOAITHUCUONG";

            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                DTO_PHANLOAI phanloai = new DTO_PHANLOAI(item);
                ds.Add(phanloai);
            }

            return ds;
        }
    }
}
