﻿using QLQCP.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQCP.DAO
{
    public class DAO_BAN
    {
        private static DAO_BAN instance;

        public static DAO_BAN Instance
        {
            get { if (instance == null) instance = new DAO_BAN(); return DAO_BAN.instance; }
            private set { DAO_BAN.instance = value; }
        }

        public static int WidthBan = 100;
        public static int HeightBan = 100;

        private DAO_BAN() { }

        public List<DTO_BAN> LoadBanList()
        {
            List<DTO_BAN> banList = new List<DTO_BAN>();

            DataTable data = DataProvider.Instance.ExecuteQuery("DANHSACHBAN");

            foreach (DataRow item in data.Rows)
            {
                DTO_BAN ban = new DTO_BAN(item);
                banList.Add(ban);
            }
            return banList;
        }
    }
}
