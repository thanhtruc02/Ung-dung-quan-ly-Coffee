﻿use QLCP
GO

CREATE TABLE BAN
(
	MaB int identity primary key,
	TenB nvarchar(100) not null DEFAULT N'Ban chua co ten',
	Trangthai nvarchar(100) not null DEFAULT N'Trong' --Có người hoặc Trống
)
GO

CREATE TABLE TAIKHOAN
(
	TenUser nvarchar(100) primary key,
	TenTK nvarchar(100) not null DEFAULT N'Abcd',
	Matkhau nvarchar (1000) not null DEFAULT 0,
	LoaiTK int not null DEFAULT 0 --1: chủ  0: nhân viên
)
GO

CREATE TABLE LOAITHUCUONG
(
	MaLoaiTU int identity primary key,
	TenLoaiTU nvarchar(100) not null DEFAULT N'Chua dat ten'
)

CREATE TABLE THUCUONG
(
	MaTU int identity primary key,
	TenTU nvarchar(100) not null DEFAULT N'Chua dat ten',
	MaLoaiTU int not null,
	Gia float not null DEFAULT 0

	FOREIGN KEY (MaLoaiTU) REFERENCES dbo.LOAITHUCUONG(MaLoaiTU)
)

CREATE TABLE HOADON
(
	MaHD int identity primary key,
	CheckIn date not null DEFAULT GETDATE(),
	CheckOut date,
	MaB int not null,
	Trangthai int not null DEFAULT 0 --1: da thanh toan 0: chua thanh toan

	FOREIGN KEY (MaB) REFERENCES dbo.BAN (MaB)
)
GO

CREATE TABLE CHITIETHOADON
(
	MaCTHD int identity primary key,
	MaHD int not null,
	MaTU int not null,
	Soluong int not null DEFAULT 0

	FOREIGN KEY (MaHD) REFERENCES dbo.HOADON (MaHD),
	FOREIGN KEY (MaTU) REFERENCES dbo.THUCUONG (MaTU)
)
GO

use QLCP
INSERT INTO dbo.TAIKHOAN
			(TenUser,
			TenTK,
			Matkhau,
			LoaiTK)
VALUES (N'chuppa',
		N'Truc',
		N'123A',
		1)

INSERT INTO dbo.TAIKHOAN
			(TenUser,
			TenTK,
			Matkhau,
			LoaiTK)
VALUES (N'allo',
		N'Thanh',
		N'123',
		0)

DECLARE @i INT = 0
WHILE @i <= 10
BEGIN
	INSERT dbo.BAN (TenB) VALUES (N'Ban  ' + CAST(@i AS nvarchar(100)))
	SET @i = @i + 1
END
UPDATE BAN SET Trangthai = N'Co nguoi' WHERE MaB = 9 OR MaB = 3;

SELECT * FROM BAN
GO

--them PHANLOAI
INSERT dbo.LOAITHUCUONG (TenLoaiTU) VALUES (N'Sinh To')
INSERT dbo.LOAITHUCUONG (TenLoaiTU) VALUES (N'Nuoc ep')
INSERT dbo.LOAITHUCUONG (TenLoaiTU) VALUES (N'Ca phe')
INSERT dbo.LOAITHUCUONG (TenLoaiTU) VALUES (N'Tra')
INSERT dbo.LOAITHUCUONG (TenLoaiTU) VALUES (N'Banh ngot')

--them THUCUONG
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Sinh To Dau', 1, 25000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Sinh To Sapoche', 1, 25000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Sinh To Mang Cau', 1, 25000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Sinh To Bo', 1, 25000)

INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Nuoc ep Tao', 2, 20000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Nuoc ep Thom', 2, 20000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Nuoc ep Dua hau', 2, 20000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Nuoc ep Ca rot', 2, 20000)

INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Ca phe den nong', 3, 18000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Ca phe den da', 3, 18000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Ca phe sua', 3, 20000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Bac siu', 3, 20000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Ca phe trung', 3, 25000)

INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Tra chanh', 4, 15000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Tra dao cam sa', 4, 25000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Tra luu', 4, 25000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Hong tra mat ong', 4, 20000)

INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Banh tiramisu', 5, 35000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Banh sung trau', 5, 25000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Pana Cotta ', 5, 20000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Banh tart trung', 5, 20000)
INSERT dbo.THUCUONG(TenTU, MaLoaiTU, Gia) VALUES (N'Banh tiramisu socola', 5, 35000)
SELECT * FROM THUCUONG

INSERT dbo.HOADON(CheckIn, CheckOut, MaB, Trangthai) VALUES (GETDATE(), GETDATE(), 1, 0)
INSERT dbo.HOADON(CheckIn, CheckOut, MaB, Trangthai) VALUES (GETDATE(), GETDATE(), 2, 0)
INSERT dbo.HOADON(CheckIn, CheckOut, MaB, Trangthai) VALUES (GETDATE(), GETDATE(), 6, 1)
INSERT dbo.HOADON(CheckIn, CheckOut, MaB, Trangthai) VALUES (GETDATE(), GETDATE(), 3, 1)
INSERT dbo.HOADON(CheckIn, CheckOut, MaB, Trangthai) VALUES (GETDATE(), GETDATE(), 5, 0)
INSERT dbo.HOADON(CheckIn, CheckOut, MaB, Trangthai) VALUES (GETDATE(), GETDATE(), 4, 1)

SELECT * FROM HOADON

INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (1, 5, 1)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (1, 8, 1)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (1, 8, 2)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (2, 1, 1)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (2, 11, 1)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (3, 20, 2)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (3, 1, 1)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (4, 17, 1)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (4, 2, 3)
INSERT dbo.CHITIETHOADON(MaHD, MaTU, Soluong) VALUES (5, 10, 2)

SELECT * FROM CHITIETHOADON


GO

CREATE PROCEDURE TAIKHOAN_TenUser
@ten nvarchar  (100)
AS
BEGIN
	SELECT * FROM dbo.TAIKHOAN WHERE TenUser= @ten
END

GO

CREATE PROCEDURE DANGNHAP
@ten nvarchar(100), @mk nvarchar(100)
AS
BEGIN
	SELECT * FROM dbo.TAIKHOAN WHERE TenUser = @ten AND Matkhau = @mk
END
GO

CREATE PROCEDURE DANHSACHBAN
AS SELECT * FROM dbo.BAN
GO

use QLCP
GO
SELECT * FROM dbo.CHITIETHOADON WHERE MaHD = 6
SELECT * FROM dbo.HOADON 


SELECT t.TenTU, c.Soluong, t.Gia, t.Gia*c.Soluong AS Tongtien
FROM dbo.CHITIETHOADON c, dbo.HOADON h, dbo.THUCUONG t
WHERE c.MaHD = h.MaHD
AND c.MaTU = t.MaTU
AND h.MaB = 3
AND h.Trangthai = 0

CREATE PROCEDURE THEMHOADON
@maB int
AS
BEGIN
	INSERT dbo.HOADON
		(CheckIn, CheckOut, MaB, Trangthai) 
	VALUES
		(GETDATE(), NULL, @maB, 0)
END
GO

CREATE PROCEDURE THEMCTHD
@maHD int, @maTU int, @soluong int
AS
BEGIN
	INSERT dbo.CHITIETHOADON
		(MaHD, MaTU, Soluong) 
	VALUES (@maHD, @maTU, @soluong)
END
GO

SELECT MAX(MaHD) FROM dbo.HOADON
GO

ALTER PROCEDURE THEMCTHD
@maHD int, @maTU int, @soluong int
AS
BEGIN
	DECLARE @isCoCTHD int;
	DECLARE @soluongmon int = 1;

	SELECT @isCoCTHD = MaCTHD, @soluongmon = c.Soluong 
	FROM dbo.CHITIETHOADON c WHERE MaHD = @maHD
	AND MaTU = @maTU;

	IF(@isCoCTHD > 0)
	BEGIN
		DECLARE @soluongmoi int = @soluongmon + @soluong
		IF (@soluongmoi >0)
			UPDATE dbo.CHITIETHOADON SET Soluong = @soluongmon + @soluong WHERE MaTU = @maTU
		ELSE
			DELETE dbo.CHITIETHOADON WHERE MaHD = @maHD AND MaTU = @maTU
	END
	ELSE 
	BEGIN
		INSERT dbo.CHITIETHOADON
			(MaHD, MaTU, Soluong) 
		VALUES (@maHD, @maTU, @soluong)
	END
	
END
GO

UPDATE dbo.HOADON SET Trangthai = 1 WHERE MaHD = 1
GO

CREATE TRIGGER CAPNHAT_CTHD
ON dbo.CHITIETHOADON FOR INSERT, UPDATE
AS
BEGIN
	DECLARE @maHD int

	SELECT @maHD = MaHD FROM inserted

	DECLARE @maB int

	SELECT @maB = MaB FROM dbo.HOADON WHERE MaHD = @maHD AND Trangthai = 0

	UPDATE dbo.BAN SET Trangthai = N'Co nguoi' WHERE MaB = @maB
END
GO

CREATE TRIGGER CAPNHAT_HD
ON dbo.HOADON FOR UPDATE
AS
BEGIN
	
	DECLARE @maHD int

	SELECT @maHD = MaHD FROM inserted

	DECLARE @maB int

	SELECT @maB = MaB FROM dbo.HOADON WHERE MaHD = @maHD 

	DECLARE @soluong int = 0;
	
	SELECT @soluong = COUNT(*) FROM dbo.HOADON WHERE MaB = @maB AND Trangthai = 0

	if(@soluong = 0)
		UPDATE dbo.BAN SET Trangthai = N'Trong'
END
GO

ALTER TRIGGER CAPNHAT_HD
ON dbo.HOADON FOR UPDATE
AS
BEGIN
	
	DECLARE @maHD int

	SELECT @maHD = MaHD FROM inserted

	DECLARE @maB int

	SELECT @maB = MaB FROM dbo.HOADON WHERE MaHD = @maHD 

	DECLARE @soluong int = 0;
	
	SELECT @soluong = COUNT(*) FROM dbo.HOADON WHERE MaB = @maB AND Trangthai = 0

	if(@soluong = 0)
		UPDATE dbo.BAN SET Trangthai = N'Trong' WHERE MaB = @maB
END
GO

DELETE dbo.CHITIETHOADON

DELETE dbo.HOADON